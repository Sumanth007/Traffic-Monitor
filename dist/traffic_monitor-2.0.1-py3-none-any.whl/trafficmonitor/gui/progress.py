import re
import json

from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon

from trafficmonitor.helper_functions import put_parser, post_parser


class Progress(QDialog):

    def __init__(self, file_name, proxy_ids, session_db):
        super().__init__()

        self.setWindowTitle("Traffic Monitor")
        self.setWindowIcon(QIcon("trafficmonitor\\images\\logo.ico"))
        self.resize(500, 20)
        self.center()

        self.progress_bar = QProgressBar()
        self.file_name = file_name
        self.proxy_ids = proxy_ids
        self.session_db = session_db

        self.init_ui()
        self.init_progress_bar()

    def center(self):
        """Method to center the QMainWindow"""
        frame_gm = self.frameGeometry()
        screen = QApplication.desktop().screenNumber(QApplication.desktop().cursor().pos())
        center_point = QApplication.desktop().screenGeometry(screen).center()
        frame_gm.moveCenter(center_point)
        self.move(frame_gm.topLeft())

    def init_ui(self):
        vertical_box = QVBoxLayout()
        vertical_box.addWidget(self.progress_bar)
        self.setLayout(vertical_box)
        self.show()

    def init_progress_bar(self):
        self.progress_bar.setMaximum(len(self.proxy_ids))

        json_list = []
        redirect_url = {}
        temp_list = []

        for count, item in enumerate(self.proxy_ids):
            check_303 = self.session_db.export_json_response(item)

            if len(check_303) > 0:

                check_303 = str(check_303[0][0])
                if check_303 == "303":
                    redirect_url_value = re.search(r"Location : (.*?)\n", check_303).group(1)
                else:
                    redirect_url_value = None
            else:
                redirect_url_value = None

            redirect_url[count] = redirect_url_value

            json_list.append(self.session_db.export_json_request(item))

        for count, item in enumerate(json_list):

            self.progress_bar.setValue(count+1)

            temp_dict = {}
            url_data = str(item[0][0]).split(":", 1)[1][2:].split("/", 1)
            ip = url_data[0]
            url = f"/{url_data[1].split('||')[0]}"
            http_ver = url_data[1].split("||")[1]
            header = item[0][1].split("\n")[:-1]
            method = item[0][3]
            raw_body = ""
            body_array = ""

            if str(method).upper() in ["GET", "HEAD", "CONNECT", "OPTIONS", "TRACE"]:
                raw_body = ""
                body_array = ""

            elif str(method).upper() in ["POST", "PUT", "PATCH", "DELETE"]:
                content_type = ("application/x-www-form-urlencoded", "text/plain", "text/xml")
                find = [i for i in header if i.startswith("Content-Type")]

                if len(find) > 0:
                    find = "".join(find).split(":", 1)[1].strip()

                    if find.startswith(content_type):
                        raw_body = item[0][2]

                        if len(raw_body) > 0:
                            if find == "text/xml":
                                body_array = put_parser(raw_body)
                            else:
                                body_array = post_parser(raw_body)

                        else:
                            body_array = ""
                            raw_body = ""
                    else:
                        continue
                else:
                    continue

            else:
                continue

            header.insert(0, f"{method} {url} {http_ver}")

            temp_dict['bodyArray'] = body_array
            temp_dict['bodyRaw'] = raw_body
            temp_dict['headers'] = header
            temp_dict['ip'] = ip

            if redirect_url[count] is None:
                temp_dict['url'] = url
            else:
                temp_dict['url'] = redirect_url[count]

            temp_list.append(temp_dict)

        temp_dict = {"baseRequests": temp_list}

        with open(self.file_name, "w") as json_file:
            json_file.write(json.dumps(temp_dict, indent=4, sort_keys=True))

        self.close()